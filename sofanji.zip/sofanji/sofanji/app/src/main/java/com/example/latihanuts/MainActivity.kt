package com.example.latihanuts

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import kotlinx.android.synthetic.main.activity_main.*

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        btn_cal.setOnClickListener {
            val intent = Intent(this, CalActivity::class.java)
            startActivity(intent)
        }


        btn_about.setOnClickListener {
            val namaku = "Sofanji"
            val email = "sofanjitok@gmail.com"
            val phone = "081548264229"

            val about = Intent(this, AboutActivity::class.java)
            about.putExtra("Namaku", namaku)
            about.putExtra("Email", email)
            about.putExtra("Phone", phone)
            startActivity(about)
        }

        btn_form.setOnClickListener {
            val beritaku = "Polda Metro Jaya menerima dua laporan polisi terkait video asusila yang diduga mirip Gisel.\n" +
                    "\n" +
                    "Pertama, laporan yang dibuat oleh seseorang bernama Febriyanto Dunggio. Laporan ini teregister dengan nomor LP: TBL/6608/XI/Yan.2.5/2020/SPKT PMJ tanggal 7 November 2020.\n" +
                    "\n" +
                    "Lalu, laporan kedua dibuat oleh Pitra Romadoni Nasution. Laporan Pitra teregister dengan nomor LP/6614/XI/YAN/SPKT.PMJ tanggal 8 November 2020. Untuk laporan Pitra ini diketahui masih dalam proses pendalaman. Kedua laporan itu diketahui telah dinaikan statusnya ke tahap penyidikan berdasarkan hasil gelar perkara.\n" +
                    "\n" +
                    "Polisi sebelumnya menyatakan ada lima akun media sosial yang menyebarkan video porno diduga mirip Gisel. Lima akun medsos tersebut adalah akun yang dilaporkan Febriyanto Dunggio.\n" +
                    "\n" +
                    "Dari lima akun itu, tiga akun medsos telah dihapus. Kendati demikian, lanjutnya, penyidik tetap mengusut jejak digital dari akun medsos tersebut."

            val berita = Intent(this, Berita2Activity::class.java)
            berita.putExtra("Berita", beritaku)
            startActivity(berita)
        }
    }
}
